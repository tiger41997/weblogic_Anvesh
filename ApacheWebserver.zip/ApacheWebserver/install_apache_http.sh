#!/bin/bash
#extract installation binary
cd /home/mwadmin/apachehttpd
tar -xzvf httpd-2.4.43.tar.gz
cd /home/mwadmin/apachehttpd/http*
APACHE_DIR_NAME=/home/mwadmin/apachehttpd/httpd-2.4.43
mkdir -p $APACHE_DIR_NAME/srclib/apr
mkdir -p $APACHE_DIR_NAME/srclib/apr-util

#extract apr
cd /home/mwadmin/apachehttpd
tar -xzvf apr-1.7.0.tar.gz
cd /home/mwadmin/apachehttpd/apr*
mv /home/mwadmin/apachehttpd/apr-1.7.0/* $APACHE_DIR_NAME/srclib/apr/

#extract apr-util
cd /home/mwadmin/apachehttpd
tar -xzvf apr-util-1.6.1.tar.gz
cd /home/mwadmin/apachehttpd/apr-util*
mv /home/mwadmin/apachehttpd/apr-util-1.6.1/* $APACHE_DIR_NAME/srclib/apr-util/


cd $APACHE_DIR_NAME
./configure --prefix=/app/apache2 --with-port=8080 --with-included-apr
make
make install

echo "start apache http server"
cd /app/apache2/bin
./apachectl -k start
