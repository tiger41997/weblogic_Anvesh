#!/bin/bash
echo '>>>>>> Status of the ManagedServer... Please wait....!!!'
Domain_Home=$1
JVM_Name=$2
log_backup_location=$3
P=`date +%d%m%Y`
mkdir -p $log_backup_location/$P/$JVM_Name
copy=$log_backup_location/$P/$JVM_Name
echo ''
cd $Domain_Home/servers/$JVM_Name/logs
echo '>>>>>> Taking backup of JVM.out'
find -mtime -2 -type f -exec cp '{}' $copy \;
echo ''
echo '>>>>>> Successfully taken backup of requested JVM logs in following path'
echo ''
echo $log_backup_location/$P
