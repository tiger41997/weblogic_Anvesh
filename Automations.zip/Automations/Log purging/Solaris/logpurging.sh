#!/bin/bash
# Author: Polu Ashok
# Purpose: LogRotation&LogPurging
# Name: logpurging.sh
#

# DECLARATIONS
RED="\033[1;31m"
NOCOLOR="\033[0m"
BASEDIR=`dirname $0`
FILEDATE=`date +%d%m%y%H%M%S`
LOGDATE=`date +%d-%m-%y' '%H':'%M':'%S`

#Determine the username
if [ `whoami` == "mwadmin" ]
then
#       DIRTOSEARCH="/apps/weblogic/domains/*/servers/*/logs /opt/weblogic/domains/*/servers/*/logs /opt/weblogic/logs/* /apps/weblogic/logs/*"
#        DIRTOSEARCH="/Weblogic/Oracle/Middleware/Oracle_Home/user_projects/domains/IGTBSTG/servers/AdminServer/logs /Weblogic/Oracle/Middleware/Oracle_Home/user_projects/domains/IGTBSTG/servers/Test_DTB_01/logs /Weblogic/Oracle/Middleware/Oracle_Home/user_projects/domains/IGTBSTG/servers/ILINK_DTB_01/logs /Weblogic/Oracle/Middleware/Oracle_Home/user_projects/domains/IGTBSTG/servers/Mobility_DTB_01/logs /Weblogic/Oracle/Middleware/Oracle_Home/user_projects/domains/IGTBSTG/servers/CBX_DTB_01/logs"
#        DIRTOSEARCH="/Weblogic/Oracle/Middleware/Oracle_Home/user_projects/domains/IGTBSTG/servers/AdminServer/logs"
        DIRTOSEARCH="/Weblogic/Oracle/logpurging/logs"
        LOGSDIRS=`ls -d $DIRTOSEARCH 2>/dev/null`
elif [ `whoami` == "tomcat" ]
then
        DIRTOSEARCH="/opt/tomcat/instances/*/logs /apps/tomcat/instances/*/logs /opt/tomcat/logs/* /apps/tomcat/logs/*"
        LOGSDIRS=`ls -d $DIRTOSEARCH 2>/dev/null`
elif [ `whoami` == "artifactory" ]
then
        DIRTOSEARCH="/opt/jfrog/artifactory/tomcat/logs"
        LOGSDIRS=`ls -d $DIRTOSEARCH 2>/dev/null`
elif [ `whoami` == "anthill" ]
then
        DIRTOSEARCH="/opt/artifactory/logs"
        LOGSDIRS=`ls -d $DIRTOSEARCH 2>/dev/null`
elif [ `whoami` == "domain" ]
then
        DIRTOSEARCH="/opt/np/domain/tomcat/logs"
        LOGSDIRS=`ls -d $DIRTOSEARCH 2>/dev/null`
elif [ `whoami` == "gym" ]
then
        DIRTOSEARCH="/opt/np/gym/tomcat/logs"
        LOGSDIRS=`ls -d $DIRTOSEARCH 2>/dev/null`
else
        echo -e "Correct the Errors before proceeding\n"
        echo -e "ERROR: Invalid User to run the script"
        echo -e "Valid Users are \n\t 1) tomcat \n\t 2) weblogic\n\t 3) artificatory"
        exit 3
fi

#Determine the Directory
if [ $BASEDIR == "." ]
then
        #Change BASEDIR to Full Path
        BASEDIR=`pwd`
fi

#Determine the number of inputs
if [ $# -ne 1 ]
then
        echo -e "Please execute the script correctly"
        echo "./logpurging.sh --retentionperiod=90days"
        exit
fi

#Check for the Proper Startup Argument
if [ `echo $1|cut -d "=" -f1` == "--retentionperiod" ]
then
        RETENTION=`echo $1|cut -d "=" -f2 | nawk -F "days" '{print $1}'`
else
        echo -e "Please execute the script correctly"
        echo "./logpurging.sh --retentionperiod=90days"
        exit
fi

LOG()
{
        echo -e "$LOGDATE $@"
}

#LOGROTATE()
#{
#        for OUTFILE in $@
#        do
#                sed "s/REPLACELOGFILE/`echo $OUTFILE|sed -f $BASEDIR/front2back.sed`/g" $BASEDIR/logrotate-out.conf-template  > $BASEDIR/logrotate-out.conf
#                /usr/sbin/logrotate -s /tmp/diskspaceman-lgrt-statusfile -f $BASEDIR/logrotate-out.conf
#
#                if [ $? -eq 0 ]
#                then
#                        LOG "-- LOGROTATION COMPLETED SUCCESSFULLY FOR $OUTFILE"
#                else
#                        LOG "-- LOGROTATION FAILED FOR $OUTFILE"
#                fi
#        done
#}


PURGE()
{
        FILETOREMOVE=`find $DIR -type f -mtime +$RETENTION -name "*.gz"`
        LOG "REMOVING THE $RED $RETENTION DAYS $NOCOLOR OLD FILES WITH GZ EXTENSION"
        LOG "LIST OF FILES GOING TO BE REMOVED: [ `echo $FILETOREMOVE|sed 's/ /,/g' ` ]"
        find $DIR -type f -mtime +$RETENTION -name "*.gz" -exec rm -vf {} \;
        LOG
                LOG "$RED G-ZIPPING THE OTHER AVAILABLE LOGS OLDER THAN 3 DAYS $NOCOLOR"
                                # PURGING THE LOG FILES OLDER THAN FIVE DAYS
                if [ `find . -type f -mtime +3 ! -name "*.gz" ! -name "*.cfg" ! -name "*.pid" ! -name "catalina.out"|wc -l` -gt 0 ]
                then
                        for logfile in `find . -type f -mtime +3 ! -name "*.gz" ! -name "*.cfg" ! -name "*.pid" ! -name "catalina.out"`
                        do
                            fuser $logfile > /dev/null 2>&1
                            if [ $? -eq 1 ]
                            then
                                LOG "Ignoring the $logfile as it seems to be a current file and locked by a process"
                            else
                                LOG "Gzipping the file $logfile"
                                gzip -v --suffix $(date +".%m-%d-%Y.gz") $logfile
                            fi
                        done
                else
                        LOG "NO LOGS FOUND FOR COMPRESS (GZIP)..SKIPPING"
                fi

}

#MAIN - START

LOG " **** DISKSPACEMAN - PROCESS STARTED ****"

LOG "LIST OF DIRECTORIES FOUND: [ `echo $LOGSDIRS|sed 's/ /,/g' ` ]"
for DIR in $LOGSDIRS
do
        LOG "==========================================================="
        LOG       "$RED###### FINNONE UAT SERVERS LOG PURGING #######$NOCOLOR"
        LOG "==========================================================="
                # INTO THE DIRECTORY
        LOG "$RED PROCESSING DIRECTORY $NOCOLOR: $DIR"
        LOG
                # Consider only the files modified today
        LISTOFFILES=`find $DIR -mtime -2 -name "*.log" -o -mtime -2 -name "*.out"`
        cd $DIR
        LOG "LIST OF FILES FOUND FOR LOGROTATION: [ `echo $LISTOFFILES|sed 's/ /,/g' ` ]"

        #Initiate Log Rotation for these files
#        LOGROTATE $LISTOFFILES

                #PURGING PROCESS STARTS
                LOG
                LOG "PURGING PROCESS STARTED  "
                PURGE $DIR
                LOG "PURGING PROCESS COMPLETED"

                # OUT OF THE DIRECTORY
                cd $BASEDIR
        LOG "==========================================================="
done

LOG
LOG " **** LOGPURGING - PROCESS COMPLETED ****"
